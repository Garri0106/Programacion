package main.java.main;

import java.util.HashSet;

import main.java.model.Usuario;

public class Principal {

	public static void main(String[] args) {
		
		/****Ampliacion********/
		HashSet<Usuario> users = new HashSet<>(10);
		/************/
		
		Usuario user1 = new Usuario("Manuel Jesus", "Garrido Castillo", "manugarricas@gmail.com", "hola");
		Usuario user2 = new Usuario("José Manuel", "Sevillano", "example@gmail.com", "hola1");
		Usuario user3 = new Usuario("José Ramón", "Sevicia", "ejemplo@gmail.com", "hola123");
		Usuario userSeguro = new Usuario("asijf", "auw", "csvhioh@kmd.com", "Holaaaaaa2");
		users.add(user1);
		users.add(user2);
		users.add(user3);
		users.add(userSeguro);
		
		System.out.println("**Mostramos los usuarios**");
		System.out.println(user1);
		System.out.println(user2);
		System.out.println(user3);
		System.out.println(userSeguro);
		System.out.println("**La contrasenia es segura**");
		System.out.println(user1.esPasswordSegura());
		System.out.println(userSeguro.esPasswordSegura());
		System.out.println("Bloqueamos un usuario");
		System.out.println(user1.esCuentaBloqueada());
		System.out.println(user1.hacerLogin("mangar100", "hola"));
		System.out.println(user1.hacerLogin("mangar100", "holaMal"));
		user1.hacerLogin("", "");
		user1.hacerLogin("", "");
		user1.hacerLogin("", "");
		user1.hacerLogin("", "");
		user1.hacerLogin("", "");
		System.out.println("**Comprobamos que este bloqueado**");
		System.out.println(user1);
		
		System.out.println("********"+ System.lineSeparator()+"Mostramos los usuarios: " +System.lineSeparator()+ "********");
		System.out.println(user1);
		for (Usuario u : users) {
			System.out.println(u);
		}
		
	}

}

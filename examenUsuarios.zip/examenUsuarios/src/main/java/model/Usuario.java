package main.java.model;

public class Usuario {
	
	private String nombre;
	private String apellidos;
	private String email;
	private int intentos;
	private Credencial credencial;
	
	public Usuario(String nombre, String apellidos, String password) {
		super();
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.credencial = new Credencial(nombre, apellidos, password);
	}
	
	public Usuario(String nombre, String apellidos, String email, String password) {
		super();
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.email = email;
		this.credencial = new Credencial(nombre, apellidos, password);
	}
	
	public boolean esCuentaBloqueada() {
		boolean estaBloqueada = false;
		if (this.intentos >= 3) {
			estaBloqueada = true;
		}
		return estaBloqueada;
	}
	
	private Credencial setCredencial(Credencial credencial) {
		return credencial;
	}
	
	public boolean modificarPassword(String oldpass, String newpass, String newpassverif) {
		boolean cambiada = false;
		
		if (oldpass.equals(newpass) && (newpass.equals(newpassverif)) && !newpass.equals(oldpass)) {
			cambiada = true;
			this.credencial.setPassword(newpass);
		}
		
		return cambiada;
	}
	
	public boolean esPasswordSegura() {
		boolean esSegura = false;
		
		if (this.credencial.esPasswordSegura()) {
			esSegura = true;
		}
		
		return esSegura;
	}
	
	public boolean hacerLogin(String username, String password) {
		boolean loginHecho = false;
		
		if (!(this.credencial.getUsername().equals(username) && this.credencial.comprobarPassword(password)) && intentos <=2) {
			this.intentos++;
		}
		else if ((this.credencial.getUsername().equals(username) && this.credencial.comprobarPassword(password)) && intentos <=2) {
			loginHecho = true;
		}
		
		return loginHecho;
	}
	
	@Override
	public String toString() {
		String mensaje = "";
		if (!this.esCuentaBloqueada()) {
			mensaje = String.format("Usuari@: %s con email %s, username %s"
					+ " y contrasenia %s", this.nombre+" "+this.apellidos, this.email,
					this.credencial.getUsername(),this.credencial.longitud());
		}
		else if (this.esCuentaBloqueada()) {
			mensaje = "Cuenta bloqueada";
		}
		return mensaje;
	}
	
	@Override
	public boolean equals(Object obj) {
		boolean sonIguales = this == obj;
		
		if (!sonIguales && obj != null && obj instanceof Usuario) {
			Usuario casteado = (Usuario)obj;
			
			if (this.email.equals(casteado.email) && this.nombre.equals(casteado.nombre) && this.apellidos.equals(casteado.apellidos) ) {
				sonIguales = true;
				
			}
			else if (this.credencial.equals(credencial)) {
				sonIguales = true;
			}
			
		}
		return sonIguales;
	}
	
}

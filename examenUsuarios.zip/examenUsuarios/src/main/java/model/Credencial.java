package main.java.model;

public class Credencial {
	
	private String username;
	private String password;
	private static int secuencia = 100;
	
	public Credencial(String nombre, String apellidos, String password) {
		super();
		nombre = nombre.substring(0, 3).toLowerCase();
		apellidos = apellidos.substring(0, 3).toLowerCase();
		this.username = nombre+apellidos+secuencia;
		this.password = password;
		this.secuencia++;
	}
	
	public boolean comprobarPassword(String password) {
		boolean esIgual = false;
		if (password.equals(this.password)) {
			esIgual = true;
		}
		return esIgual;
	}
	
	public String getUsername() {
		return username;
	}

	public boolean esPasswordSegura() {
		boolean esSegura = false;
		boolean mayus = false;
		boolean minus = false;
		//boolean number = false;
		
		if (this.password != null && this.password.length()>= 8 && !this.password.isEmpty()) {
			for (int i=0; i < this.password.length(); i++) {
				
				char c = this.password.charAt(i);
				String str = String.valueOf(c);
				
				if (str.equals(str.toLowerCase())) {
					minus = true;
				}
				
				else if (str.equals(str.toUpperCase())) {
					this.password.charAt(i);
					mayus = true;
				}
//				else if (c > '0' && c < '9') {
//					number = true;
//				}
			}
			if (mayus && minus/* && number*/) {
				esSegura = true;
			}
			
		}
		
		return esSegura;
	}
	
	public String longitud() {
		String resultado = "";
		for (int i=0;i<this.password.length();i++) {
			resultado += "*";
		}
		return resultado;
	}
	
	public void setPassword(String newpass) {
		this.password = newpass;
	}
	
	@Override
	public boolean equals(Object obj) {
		boolean sonIguales = this == obj;
		
		if (!sonIguales && obj != null && obj instanceof Credencial) {
			Credencial casteado = (Credencial)obj;
			
			sonIguales = this.username.equals(casteado.username);
		}
		return sonIguales;
	}
	
}
